CREATE TABLE ACMA_SPECIALTY (
    specialty_id number not null,
    description varchar2(512),
    primary key (specialty_id)
);
