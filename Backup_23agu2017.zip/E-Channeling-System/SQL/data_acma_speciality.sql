﻿prompt Importing table acma_specialty...
set feedback off
set define off
insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (19, 'Neurological surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (20, 'Neurologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (21, 'Nuclear medicine specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (22, 'Obstetrician');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (23, 'Occupational medicine specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (24, 'Oncologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (25, 'Ophthalmologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (26, 'Oral surgeon (maxillofacial surgeon)');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (27, 'Orthopedic surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (28, 'Otolaryngologist (ear, nose, and throat specialist)');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (29, 'Pain management specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (30, 'Pathologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (31, 'Pediatrician');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (32, 'Perinatologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (33, 'Physiatrist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (34, 'Plastic surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (35, 'Psychiatrist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (36, 'Pulmonologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (37, 'Radiation oncologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (38, 'Radiologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (39, 'Reproductive endocrinologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (40, 'Rheumatologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (41, 'Sleep disorders specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (42, 'Spinal cord injury specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (43, 'Sports medicine specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (44, 'Surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (45, 'Thoracic surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (46, 'Urologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (47, 'Vascular surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (1, 'Eye seargen');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (2, 'Addiction psychiatrist.');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (3, 'Adolescent medicine specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (4, 'Allergist ');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (5, 'Anesthesiologist ');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (6, 'Cardiac electrophysiologist ');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (7, 'Cardiologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (8, 'Cardiovascular surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (9, 'Colon and rectal surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (10, 'Dermatologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (11, 'Hand surgeon');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (12, 'Hyperbaric physician');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (14, 'Infectious disease specialist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (15, 'Internist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (16, 'Interventional cardiologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (17, 'Neonatologist');

insert into acma_specialty (SPECIALTY_ID, DESCRIPTION)
values (18, 'Nephrologist');

prompt Done.
