INSERT INTO ACMA_DOCTOR
VALUES (001,'Dr.Charith Ellawala',0710868686,'Dutugemunu street,Pamankada','85055135v',0,5,10,12,'charith','123','charith@gmail.com');
INSERT INTO ACMA_DOCTOR
VALUES (002,'Dr.Kalpita Nuwan',0710868851,'Nawala street,Rajagiriya','85055138v',1,8,7,4,'kalpita','123','kalpita@gmail.com');
INSERT INTO ACMA_DOCTOR
VALUES (003,'Dr.Chathuri Upeksha',0710867526,'Kings Road ,Colombo6','85055137v',0,7,15,13,'chathuri','123','chathuri@gmail.com');
INSERT INTO ACMA_DOCTOR
VALUES (004,'Dr.Dinesh Nanayakkara',0710845986,'No43,Galle Road,Hikkaduwa','850456135v',1,25,5,9,'dinesh','123','dinesh@gmail.com');
INSERT INTO ACMA_DOCTOR
VALUES (005,'Dr.Maduka Serasinghe',0710868156,'AB923,Nuwara Road,Pilimathalawa','85055145v',1,10,10,6,'maduka','123','maduka@gmail.com');
INSERT INTO ACMA_DOCTOR
VALUES (006,'Dr.Tharaka Welpita',071086874,'No45,Distinct Road,Hatton','85785135v',0,8,10,16,'tharaka','123','tharaka@gmail.com');

COMMIT
