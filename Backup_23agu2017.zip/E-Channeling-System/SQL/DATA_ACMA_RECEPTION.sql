INSERT INTO ACMA_RECEPTION
VALUES (001,'Channa Liyanage','channa@outlook.com',0710828282,'channa','123')

COMMIT 
