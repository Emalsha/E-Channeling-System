insert into acma_patient
values(002,'Afrar','940280584v',0778114143,'Hatton, Srilanka');
